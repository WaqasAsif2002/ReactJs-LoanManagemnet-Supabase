import React from 'react';
import { Button, Container } from 'react-bootstrap';

export default function UserDashboard() {
  // Simple user dashboard with logout and request button
  const handleLogout = () => {
    alert('Logout clicked! Implement logout logic here.');
  };

  const handleRequest = () => {
    alert('Request clicked! Implement request logic here.');
  };

  return (
    <Container className="mt-5">
      <h2>User Dashboard</h2>
      <p>Welcome, User!</p>
      <Button variant="danger" className="me-2" onClick={handleLogout}>
        Logout
      </Button>
      <Button variant="primary" onClick={handleRequest}>
        Make Request
      </Button>
    </Container>
  );
}
