import React from 'react';
import { Button, Container } from 'react-bootstrap';

export default function AdminDashboard() {
  // Simple admin dashboard with logout and request button
  const handleLogout = () => {
    alert('Logout clicked! Implement logout logic here.');
  };

  const handleRequest = () => {
    alert('Request clicked! Implement request logic here.');
  };

  return (
    <Container className="mt-5">
      <h2>Admin Dashboard</h2>
      <p>Welcome, Admin!</p>
      <Button variant="danger" className="me-2" onClick={handleLogout}>
        Logout
      </Button>
      <Button variant="primary" onClick={handleRequest}>
        Make Request
      </Button>
    </Container>
  );
}
